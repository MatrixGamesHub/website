from .PacMan import PacMan
from .Sokoban import Sokoban
from .Wesp import Wesp

GameList = [PacMan, Sokoban, Wesp]